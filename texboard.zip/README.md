# Texboard
A Chrome extension for rendering LaTeX into equation images. Use it to easily add equations to emails and presentations.

![screenshot](https://lh3.googleusercontent.com/plF7oq5rrJ45p0e0fyrdWgb9y_AUu5qN1dXlpDfpX7ArQ2f3v21AqO5Fr5GujtvmLgO5L9uo=w640-h400-e365)

Install it here:
https://chrome.google.com/webstore/detail/texboard/ndaefkidgejehobioaplkhiembjacdnb?hl=en-US
